<?php
$dbhost = 'localhost';
$dbuser = 'WebDesign2020';
$dbpass = '707h3Fu7ur32';
$dbname = 'webdesign2020';
?>